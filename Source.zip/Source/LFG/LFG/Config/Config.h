#pragma once

namespace Config
{
	void Load();

	void Update(bool showMenu);

	bool InitialShowMenu();
}
