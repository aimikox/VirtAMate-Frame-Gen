#include "Config.h"
#include <Windows.h>
#include <string>
#include <cstdio>
#include <cstdlib>
#include <Debug/Debug.h>
#include <Pipeline/Generation/FrameGeneration.h>

extern HMODULE g_hModule;

#define LFG_SETTINGS(B, I, F, E) \
	B(System, DisableVSync) B(System, LowLatencyMode) B(System, EnableAsyncCompute) \
	B(FPSCap, FPSCap) I(FPSCap, TargetFPS) E(FPSCap, CapMode) \
	I(Generation, MultiFrameCount) B(Generation, EnableDynamicRatio) B(Generation, EnableAggressiveDynamicMode) I(Generation, DynamicTargetFPS) \
	F(Upscaling, RenderScale) E(Upscaling, UpscaleMode) I(Upscaling, LanczosRadius) \
	I(OpticalFlow, OpticalFlowAlgorithm) I(OpticalFlow, BlockSize) I(OpticalFlow, SearchRadius) \
	I(OpticalFlow, MaxPyramidLevel) I(OpticalFlow, MinPyramidLevel) B(OpticalFlow, EnableBiDirFlow) \
	B(OpticalFlow, EnableAdaptiveBlock) B(OpticalFlow, EnableSubPixel) F(OpticalFlow, MotionSensitivity) \
	F(Quality, RcasStrength) F(Quality, GhostingReduction) B(Quality, EnableEdgeProtection) \
	B(Quality, EnableMotionSmoothing) I(Quality, SceneChangeThreshold) \
	B(Debug, ShowDebugOverlay) I(Debug, DebugViewMode) F(Debug, HUDThreshold) \
	B(Debug, EnableSplitScreen) F(Debug, SplitScreenPosition)

namespace
{
	std::string g_Path;
	std::string g_LastSaved;
	std::string g_Pending;
	ULONGLONG g_PendingSince = 0;
	bool g_ShowMenu = true;

	std::string IniPath()
	{
		char buf[MAX_PATH] = {};
		GetModuleFileNameA(g_hModule, buf, MAX_PATH);
		std::string p(buf);
		size_t slash = p.find_last_of("\\/");
		return (slash != std::string::npos ? p.substr(0, slash + 1) : std::string()) + "LFG.ini";
	}

	bool ReadStr(const char* sec, const char* key, std::string& out)
	{
		char buf[64] = {};
		GetPrivateProfileStringA(sec, key, "\x01", buf, sizeof(buf), g_Path.c_str());
		if (buf[0] == '\x01') return false;
		out = buf;
		return true;
	}

	int ReadInt(const char* sec, const char* key, int def)
	{
		std::string s;
		return ReadStr(sec, key, s) ? atoi(s.c_str()) : def;
	}

	float ReadFloat(const char* sec, const char* key, float def)
	{
		std::string s;
		return ReadStr(sec, key, s) ? (float)atof(s.c_str()) : def;
	}

	std::string FmtFloat(float v)
	{
		char buf[32];
		for (int prec = 3; prec <= 9; ++prec)
		{
			snprintf(buf, sizeof(buf), "%.*g", prec, (double)v);
			if ((float)atof(buf) == v) break;
		}
		return buf;
	}

	template <typename T> T Clamp(T v, T lo, T hi) { return v < lo ? lo : (v > hi ? hi : v); }

	void Sanitize(FrameGeneration::FrameGenSettings& s)
	{
		s.TargetFPS = Clamp(s.TargetFPS, 0, 1000);
		s.MultiFrameCount = Clamp(s.MultiFrameCount, 0, 5);
		s.DynamicTargetFPS = Clamp(s.DynamicTargetFPS, 0, 1000);
		s.RenderScale = Clamp(s.RenderScale, 0.25f, 1.0f);
		s.LanczosRadius = Clamp(s.LanczosRadius, 1, 4);
		s.OpticalFlowAlgorithm = Clamp(s.OpticalFlowAlgorithm, 0, 2);
		s.BlockSize = Clamp(s.BlockSize, 4, 64);
		s.SearchRadius = Clamp(s.SearchRadius, 1, 64);
		s.MaxPyramidLevel = Clamp(s.MaxPyramidLevel, 0, 2);
		s.MinPyramidLevel = Clamp(s.MinPyramidLevel, 0, 2);
		s.DebugViewMode = Clamp(s.DebugViewMode, 0, 2);
		s.SplitScreenPosition = Clamp(s.SplitScreenPosition, 0.0f, 1.0f);
		int cap = Clamp((int)s.CapMode, 0, 1);
		s.CapMode = (FrameGeneration::FrameGenSettings::FpsCapMode)cap;
		int up = Clamp((int)s.UpscaleMode, 0, 4);
		s.UpscaleMode = (FrameGeneration::FrameGenSettings::UpscaleType)up;
	}

	std::string Serialize(bool enabled, bool showMenu)
	{
		const auto& s = FrameGeneration::Instance().GetSettings();
		std::string out;
		out += "; LFG VaM Edition by AimiKo - settings (written automatically when changed in the menu)\n";
		out += "; Delete this file to reset everything to defaults.\n";
		out += "\n[General]\n";
		out += std::string("Enabled=") + (enabled ? "1" : "0") + "\n";
		out += std::string("ShowMenu=") + (showMenu ? "1" : "0") + "\n";

		std::string section = "General";
		char line[128];
		auto header = [&](const char* sec)
		{
			if (section != sec) { section = sec; out += "\n["; out += sec; out += "]\n"; }
		};

#define SAVE_B(sec, f) header(#sec); out += #f "="; out += (s.f ? "1" : "0"); out += "\n";
#define SAVE_I(sec, f) header(#sec); snprintf(line, sizeof(line), #f "=%d\n", s.f); out += line;
#define SAVE_F(sec, f) header(#sec); out += #f "="; out += FmtFloat(s.f); out += "\n";
#define SAVE_E(sec, f) header(#sec); snprintf(line, sizeof(line), #f "=%d\n", (int)s.f); out += line;
		LFG_SETTINGS(SAVE_B, SAVE_I, SAVE_F, SAVE_E)
#undef SAVE_B
#undef SAVE_I
#undef SAVE_F
#undef SAVE_E
		return out;
	}

	bool WriteFileAtomic(const std::string& text)
	{
		std::string tmp = g_Path + ".tmp";
		FILE* f = nullptr;
		if (fopen_s(&f, tmp.c_str(), "wb") != 0 || !f) return false;
		size_t n = fwrite(text.data(), 1, text.size(), f);
		fclose(f);
		if (n != text.size()) { DeleteFileA(tmp.c_str()); return false; }
		return MoveFileExA(tmp.c_str(), g_Path.c_str(), MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH) != 0;
	}
}

void Config::Load()
{
	g_Path = IniPath();
	auto& fg = FrameGeneration::Instance();
	auto& s = fg.GetSettings();

	if (GetFileAttributesA(g_Path.c_str()) == INVALID_FILE_ATTRIBUTES)
	{
		g_LastSaved = Serialize(fg.IsEnabled(), g_ShowMenu);
		if (WriteFileAtomic(g_LastSaved)) Debug::Info("Created %s with default settings", g_Path.c_str());
		else Debug::Error("Could not create %s", g_Path.c_str());
		return;
	}

	fg.SetEnabled(ReadInt("General", "Enabled", fg.IsEnabled() ? 1 : 0) != 0);
	g_ShowMenu = ReadInt("General", "ShowMenu", 1) != 0;

#define LOAD_B(sec, f) s.f = ReadInt(#sec, #f, s.f ? 1 : 0) != 0;
#define LOAD_I(sec, f) s.f = ReadInt(#sec, #f, s.f);
#define LOAD_F(sec, f) s.f = ReadFloat(#sec, #f, s.f);
#define LOAD_E(sec, f) s.f = (decltype(s.f))ReadInt(#sec, #f, (int)s.f);
	LFG_SETTINGS(LOAD_B, LOAD_I, LOAD_F, LOAD_E)
#undef LOAD_B
#undef LOAD_I
#undef LOAD_F
#undef LOAD_E

	Sanitize(s);
	g_LastSaved = Serialize(fg.IsEnabled(), g_ShowMenu);
	Debug::Info("Settings loaded from %s", g_Path.c_str());
}

void Config::Update(bool showMenu)
{
	if (g_Path.empty()) return;

	std::string now = Serialize(FrameGeneration::Instance().IsEnabled(), showMenu);
	if (now == g_LastSaved) { g_Pending.clear(); return; }

	ULONGLONG t = GetTickCount64();
	if (now != g_Pending) { g_Pending = now; g_PendingSince = t; return; }

	if (t - g_PendingSince >= 1000)
	{
		if (WriteFileAtomic(now)) g_LastSaved = now;
		else g_PendingSince = t;
		g_Pending.clear();
	}
}

bool Config::InitialShowMenu()
{
	return g_ShowMenu;
}
