@echo off
rem Builds LFG.dll without opening Visual Studio.
rem Alternatively open LFG\LFG.sln in Visual Studio 2022 and build Release x64.
setlocal
set VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe
for /f "usebackq tokens=*" %%i in (`"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set VSDIR=%%i
if not defined VSDIR (
    echo Visual Studio with C++ tools not found.
    exit /b 1
)
call "%VSDIR%\VC\Auxiliary\Build\vcvars64.bat" >nul || exit /b 1

set SRC=%~dp0LFG\LFG
set OUT=%~dp0out
if not exist "%OUT%\obj" mkdir "%OUT%\obj"
pushd "%SRC%"

cl /nologo /c /O2 /Oi /GL /MT /EHsc /W3 /std:c++latest /permissive- /utf-8 ^
   /DNDEBUG /DLFG_EXPORTS /D_WINDOWS /D_USRDLL /D_MBCS ^
   /I. /IDependencies\ImGui /IDependencies\ImGui\backends /IDependencies\MinHook ^
   /Fo"%OUT%\obj\\" ^
   Debug\Debug.cpp DllMain.cpp DirectX\DirectX.cpp ^
   Hook\Engine\HookEngine.cpp Hook\Present\Present.cpp Hook\ResizeBuffers\ResizeBuffers.cpp ^
   Pipeline\Generation\FrameGeneration.cpp Pipeline\Interpolation\FrameInterpolation.cpp ^
   Pipeline\OpticalFlow\OpticalFlow.cpp Pipeline\Processing\EdgeDetection.cpp ^
   Pipeline\Processing\Sharpening.cpp Pipeline\Shaders\Shader.cpp ^
   UI\DebugOverlay.cpp UI\Menu.cpp Config\Config.cpp ^
   Dependencies\ImGui\backends\imgui_impl_dx11.cpp Dependencies\ImGui\backends\imgui_impl_win32.cpp ^
   Dependencies\ImGui\imgui.cpp Dependencies\ImGui\imgui_demo.cpp Dependencies\ImGui\imgui_draw.cpp ^
   Dependencies\ImGui\imgui_tables.cpp Dependencies\ImGui\imgui_widgets.cpp
if errorlevel 1 ( popd & exit /b 1 )

cl /nologo /c /O2 /GL /MT /W3 /DNDEBUG /Fo"%OUT%\obj\\" ^
   Dependencies\MinHook\src\buffer.c Dependencies\MinHook\src\hde\hde32.c Dependencies\MinHook\src\hde\hde64.c ^
   Dependencies\MinHook\src\hook.c Dependencies\MinHook\src\trampoline.c
if errorlevel 1 ( popd & exit /b 1 )
popd

link /nologo /DLL /LTCG /OPT:REF /OPT:ICF /OUT:"%OUT%\LFG.dll" "%OUT%\obj\*.obj" ^
   d3d11.lib dxgi.lib d3dcompiler.lib user32.lib kernel32.lib gdi32.lib shell32.lib imm32.lib dwmapi.lib
if errorlevel 1 exit /b 1
echo Done: %OUT%\LFG.dll
endlocal
