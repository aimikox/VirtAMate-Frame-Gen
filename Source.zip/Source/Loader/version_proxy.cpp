// VAMLSFG Loader - AimiKo

#define WIN32_LEAN_AND_MEAN
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0A00
#endif
#include <windows.h>
#include <stdio.h>
#include <timeapi.h>
#pragma comment(lib, "winmm.lib")

#ifndef PROCESS_POWER_THROTTLING_CURRENT_VERSION
#define PROCESS_POWER_THROTTLING_CURRENT_VERSION 1
#endif
#ifndef PROCESS_POWER_THROTTLING_EXECUTION_SPEED
#define PROCESS_POWER_THROTTLING_EXECUTION_SPEED 0x1
#endif
#ifndef PROCESS_POWER_THROTTLING_IGNORE_TIMER_RESOLUTION
#define PROCESS_POWER_THROTTLING_IGNORE_TIMER_RESOLUTION 0x4
#endif

#define FWD(name) __pragma(comment(linker, "/export:" #name "=\\\\.\\GLOBALROOT\\SystemRoot\\System32\\version.dll." #name))
FWD(GetFileVersionInfoA)
FWD(GetFileVersionInfoByHandle)
FWD(GetFileVersionInfoExA)
FWD(GetFileVersionInfoExW)
FWD(GetFileVersionInfoSizeA)
FWD(GetFileVersionInfoSizeExA)
FWD(GetFileVersionInfoSizeExW)
FWD(GetFileVersionInfoSizeW)
FWD(GetFileVersionInfoW)
FWD(VerFindFileA)
FWD(VerFindFileW)
FWD(VerInstallFileA)
FWD(VerInstallFileW)
FWD(VerLanguageNameA)
FWD(VerLanguageNameW)
FWD(VerQueryValueA)
FWD(VerQueryValueW)

static wchar_t g_dir[MAX_PATH];

static void Log(const wchar_t* fmt, ...)
{
    wchar_t path[MAX_PATH];
    swprintf_s(path, L"%slfg_loader.log", g_dir);
    FILE* f = NULL;
    if (_wfopen_s(&f, path, L"a, ccs=UTF-8") != 0 || !f) return;
    SYSTEMTIME t;
    GetLocalTime(&t);
    fwprintf(f, L"[%02d:%02d:%02d] ", t.wHour, t.wMinute, t.wSecond);
    va_list ap;
    va_start(ap, fmt);
    vfwprintf(f, fmt, ap);
    va_end(ap);
    fwprintf(f, L"\n");
    fclose(f);
}

static BOOL CALLBACK FindMainWindow(HWND h, LPARAM lp)
{
    DWORD pid = 0;
    GetWindowThreadProcessId(h, &pid);
    if (pid == GetCurrentProcessId() && IsWindowVisible(h) && GetWindow(h, GW_OWNER) == NULL)
    {
        *(HWND*)lp = h;
        return FALSE;
    }
    return TRUE;
}

static void ApplyProcessTweaks(const wchar_t* ini)
{
    wchar_t prio[32];
    GetPrivateProfileStringW(L"Process", L"Priority", L"High", prio, 32, ini);
    DWORD cls = 0;
    if (_wcsicmp(prio, L"High") == 0) cls = HIGH_PRIORITY_CLASS;
    else if (_wcsicmp(prio, L"AboveNormal") == 0) cls = ABOVE_NORMAL_PRIORITY_CLASS;
    else if (_wcsicmp(prio, L"Normal") == 0) cls = NORMAL_PRIORITY_CLASS;
    if (cls)
    {
        if (SetPriorityClass(GetCurrentProcess(), cls)) Log(L"Priority set to %s", prio);
        else Log(L"SetPriorityClass failed (%lu)", GetLastError());
    }

    if (GetPrivateProfileIntW(L"Process", L"DisablePowerThrottling", 1, ini))
    {
        typedef BOOL(WINAPI* SetProcInfoFn)(HANDLE, int, LPVOID, DWORD);
        SetProcInfoFn fn = (SetProcInfoFn)GetProcAddress(GetModuleHandleW(L"kernel32.dll"), "SetProcessInformation");
        struct { ULONG Version, ControlMask, StateMask; } st;
        st.Version = PROCESS_POWER_THROTTLING_CURRENT_VERSION;
        st.ControlMask = PROCESS_POWER_THROTTLING_EXECUTION_SPEED | PROCESS_POWER_THROTTLING_IGNORE_TIMER_RESOLUTION;
        st.StateMask = 0;
        const int ProcessPowerThrottling = 4;
        if (fn && fn(GetCurrentProcess(), ProcessPowerThrottling, &st, sizeof(st)))
            Log(L"Power throttling disabled");
        else
        {
            st.ControlMask = PROCESS_POWER_THROTTLING_EXECUTION_SPEED;
            if (fn && fn(GetCurrentProcess(), ProcessPowerThrottling, &st, sizeof(st)))
                Log(L"Power throttling disabled (execution speed only)");
            else
                Log(L"Could not disable power throttling (%lu)", GetLastError());
        }
    }

    if (GetPrivateProfileIntW(L"Process", L"TimerResolution1ms", 1, ini))
    {
        if (timeBeginPeriod(1) == TIMERR_NOERROR) Log(L"Timer resolution 1 ms");
        else Log(L"timeBeginPeriod(1) failed");
    }
}

static DWORD WINAPI LoaderThread(LPVOID)
{
    wchar_t ini[MAX_PATH], dllName[MAX_PATH], dllPath[MAX_PATH];
    swprintf_s(ini, L"%slfg_loader.ini", g_dir);

    ApplyProcessTweaks(ini);

    if (!GetPrivateProfileIntW(L"Loader", L"Enabled", 1, ini))
    {
        Log(L"Disabled in lfg_loader.ini");
        return 0;
    }
    int delay = (int)GetPrivateProfileIntW(L"Loader", L"DelaySeconds", 5, ini);
    GetPrivateProfileStringW(L"Loader", L"Dll", L"LFG.dll", dllName, MAX_PATH, ini);
    swprintf_s(dllPath, L"%s%s", g_dir, dllName);

    if (GetFileAttributesW(dllPath) == INVALID_FILE_ATTRIBUTES)
    {
        Log(L"Not found: %s", dllPath);
        return 0;
    }

    HWND wnd = NULL;
    for (int i = 0; i < 1800 && !wnd; i++)
    {
        EnumWindows(FindMainWindow, (LPARAM)&wnd);
        if (!wnd) Sleep(100);
    }
    if (!wnd)
    {
        Log(L"Game window not found, not loading %s", dllName);
        return 0;
    }

    Log(L"Window found, waiting %d s", delay);
    Sleep((DWORD)delay * 1000);

    HMODULE m = LoadLibraryW(dllPath);
    if (m) Log(L"Loaded %s", dllPath);
    else   Log(L"LoadLibrary failed for %s (error %lu)", dllPath, GetLastError());
    return 0;
}

BOOL WINAPI DllMain(HINSTANCE hinst, DWORD reason, LPVOID)
{
    if (reason != DLL_PROCESS_ATTACH) return TRUE;
    DisableThreadLibraryCalls(hinst);

    wchar_t exe[MAX_PATH];
    DWORD n = GetModuleFileNameW(NULL, exe, MAX_PATH);
    if (n == 0 || n >= MAX_PATH) return TRUE;

    const wchar_t* name = wcsrchr(exe, L'\\');
    name = name ? name + 1 : exe;
    if (_wcsicmp(name, L"VaM.exe") != 0) return TRUE;

    wcsncpy_s(g_dir, exe, (size_t)(name - exe));
    HANDLE t = CreateThread(NULL, 0, LoaderThread, NULL, 0, NULL);
    if (t) CloseHandle(t);
    return TRUE;
}
