@echo off
setlocal
set VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe
for /f "usebackq tokens=*" %%i in (`"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set VSDIR=%%i
if not defined VSDIR (
    echo Visual Studio with C++ tools not found.
    exit /b 1
)
call "%VSDIR%\VC\Auxiliary\Build\vcvars64.bat" >nul || exit /b 1

cd /d "%~dp0"
if not exist out mkdir out
cl /nologo /LD /O2 /MT /W3 /DUNICODE /D_UNICODE version_proxy.cpp /Foout\ /link /OUT:out\version.dll /IMPLIB:out\version_proxy.lib user32.lib kernel32.lib || exit /b 1
echo Done: %~dp0out\version.dll
endlocal
